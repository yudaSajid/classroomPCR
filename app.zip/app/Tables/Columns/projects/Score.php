<?php

namespace App\Tables\Columns\projects;

use Filament\Tables\Columns\Column;

class Score extends Column
{
    protected string $view = 'tables.columns.projects.score';
}

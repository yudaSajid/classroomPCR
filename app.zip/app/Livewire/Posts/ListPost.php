<?php

namespace App\Livewire\Posts;

use App\Models\Post;
use Livewire\Component;
use Livewire\WithPagination;

class ListPost extends Component
{
    use WithPagination;
    public $courseID;
    public $post;
    public int | string $perPage = 10;

    public function mount($courseID): void
    {
        $this->courseID = $courseID;
    }

    public function render()
    {
        $posts = Post::where('course_id', $this->courseID)
        ->latest()
        ->paginate($this->perPage);

// Make sure $posts is not null, and is a LengthAwarePaginator instance.
if (is_null($posts)) {
$posts = collect();  // Default to an empty collection if null
}

return view('livewire.posts.list-post', ['posts' => $posts]);
    }
}

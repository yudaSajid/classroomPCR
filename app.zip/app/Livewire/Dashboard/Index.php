<?php

namespace App\Livewire\Dashboard;

use App\Models\Point as Points;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Index extends Component
{
    public $points;
    public $user;

    public function mount()
    {
      $this->user = Auth::id();
        $this->points = $this->formatPoints(
          Points::where('user_id', $this->user)
              ->sum('points')
      );
    }

    private function formatPoints($points) {
      if ($points < 1000) {
          return $points;
      } elseif ($points < 1000000) {
          return number_format($points / 1000, 0) . 'K';
      } elseif ($points < 1000000000) {
          return number_format($points / 1000000, 0) . 'M';
      } else {
          return number_format($points / 1000000000, 0) . 'B';
      }
  }
    public function render()
    {
        return view('livewire.dashboard.index');
    }
}

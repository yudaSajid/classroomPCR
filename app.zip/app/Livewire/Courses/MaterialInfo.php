<?php

namespace App\Livewire\Courses;

use App\Models\Assignment;
use App\Models\Chapter;
use App\Models\Material;
use App\Models\Quiz;
use App\Models\QuizAttempt;
use App\Models\UserMaterialStatus;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Livewire\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\On;

class MaterialInfo extends Component
{
    public $materialId;
    public $quizId;
    public $material;
    public $quiz;
    public $message;
    public $selectedLanguage;
    public $iframeSrc;
    public $quizAttempts;
    public $assignmentId;
    public $assignment;

    protected $languages = [
        'PHP' => 'https://www.programiz.com/php/online-compiler/',
        'HTML' => 'https://www.programiz.com/html/online-compiler/',
        'Java' => 'https://www.programiz.com/java-programming/online-compiler/',
        'Python' => 'https://www.programiz.com/python-programming/online-compiler/',
        'C#' => 'https://www.programiz.com/cpp-programming/online-compiler/',
        'NodeJS' => 'https://www.programiz.com/javascript/online-compiler/',
        'React' => 'https://onecompiler.com/javascript/3wg6rpqz2',
        'SQL' => 'https://www.programiz.com/sql/online-compiler/',
    ];

    public function mount()
    {
        $this->selectedLanguage = array_key_first($this->languages); // Set default language
        $this->iframeSrc = $this->languages[$this->selectedLanguage];
    }

    public function updatedSelectedLanguage()
    {
        $this->iframeSrc = $this->languages[$this->selectedLanguage];
    }
    #[On('quizSelected')]
    #[On('assignmentSelected')]
    #[On('materialSelected')]
    public function updateMaterial($materialId = null, $quizId = null, $assignmentId = null)
    {
        if ($quizId) {
            // Tampilkan data quiz jika quizId diberikan
            $quiz = Quiz::find($quizId);
            if (!$quiz) {
                Log::warning('Quiz not found for ID: ' . $quizId);
                $this->quiz = null;
                $this->message = "Quiz not found.";
                return false;
            }
            if (!$this->checkPreviousQuizScore($quiz->chapter_id)) {
                $this->message = "You must score 100 on the previous chapter quiz before you can access this quiz.";
                return false;
            } else {
                $this->quiz = $quiz;
                $this->material = null; // Reset material jika menampilkan quiz
                $this->message = null;
            }

            // Ambil quiz_attempts untuk user_id saat ini dan quiz_id yang dipilih
            $userId = Auth::id();
            $this->quizAttempts = QuizAttempt::where('quiz_id', $quizId)
                ->where('user_id', $userId)
                ->get();
            return true;
        } else if ($materialId) {
            $userId = Auth::id();
            $material = Material::find($materialId);
            if (!$material) {
                $this->message = "Material not found.";
                $this->material = null;
                return false;
            }
            if ($material->order_number == 1) {
                $firstChapterNumber = $material->chapter->course->chapters->min('chapter_number');
                if ($material->chapter->chapter_number == $firstChapterNumber) {
                    UserMaterialStatus::firstOrCreate(
                        ['user_id' => $userId, 'material_id' => $material->id],
                        ['is_completed' => 1, 'completed_at' => now()]
                    );
                } else {
                    // code jika user sudah menyelesaikan quiz pada chapter sebelumnya
                    if (!$this->checkPreviousQuizScore($material->chapter_id)) {
                        $this->message = "You must score 100 on the previous chapter quiz before you can view this material.";
                        $this->material = null;
                        return false;
                    } else {
                        UserMaterialStatus::firstOrCreate(
                            ['user_id' => $userId, 'material_id' => $material->id],
                            ['is_completed' => 1, 'completed_at' => now()]
                        );
                    }
                }
                $this->material = $material;
                $this->message = null;
                $this->quiz = null;
                return true;
            } else {
                // Cek apakah user dapat melihat materi ini
                if ($this->canViewMaterial($userId, $material)) {
                    $this->material = $material;
                    $this->quiz = null; // Reset quiz jika menampilkan material
                    $this->message = null;
                    return true;
                } else {
                    // Jika tidak dapat melihat materi, tampilkan pesan
                    $this->material = null;
                    $this->message = "You cannot access this material because you have not completed the previous material.";
                    $this->quiz = null;
                    return false;
                }
            }
        } else if ($assignmentId) {
            $this->material = null;
            $this->quiz = null;
            $this->message = null;
            $this->assignmentId = $assignmentId;
            $this->assignment = Assignment::where('id', $this->assignmentId)
                ->first();
        }

        $this->message = "Please select material or quiz.";
        return false;
    }

    public function canViewMaterial($userId, $material)
    {
        // Cek material sebelumnya apakah sudah selesai
        $previousOrderNumber = $this->getPreviousOrderNumber($material->order_number, $material->chapter_id);
        if ($previousOrderNumber) {
            $previousMaterialCompleted = Material::where('chapter_id', $material->chapter_id)
                ->where('order_number', $previousOrderNumber)
                ->whereHas('userMaterialStatus', function ($query) use ($userId) {
                    $query->where('user_id', $userId)
                        ->where('is_completed', 1);
                })
                ->exists();

            // Jika material sebelumnya belum selesai, return false
            if (!$previousMaterialCompleted) {
                return false;
            }
        }

        // Jika material sebelumnya selesai, atau ini material pertama, lakukan pengecekan atau insert status
        $status = UserMaterialStatus::firstOrCreate(
            ['user_id' => $userId, 'material_id' => $material->id],
            ['is_completed' => 0, 'completed_at' => now()->addSeconds($this->convertDurationToSeconds($material->duration))]
        );

        // Cek apakah materi saat ini sudah diselesaikan
        if ($status) {

            // Cek apakah waktu sekarang sudah melewati waktu penyelesaian
            if (now()->gt($status->completed_at)) {
                // Tandai material sebagai selesai jika waktu sekarang telah melewati waktu penyelesaian
                $status->update(['is_completed' => 1]);
                return true;
            }
            return true;
        }

        // Materi saat ini belum selesai, dan waktu penyelesaian belum terlampaui
        return false;
    }


    private function getPreviousOrderNumber($currentOrderNumber, $chapterId)
    {
        return Material::where('chapter_id', $chapterId)
            ->where('order_number', '<', $currentOrderNumber)
            ->max('order_number');
    }
    private function getNextOrderNumber($currentOrderNumber, $chapterId)
    {
        return Material::where('chapter_id', $chapterId)
            ->where('order_number', '>', $currentOrderNumber)
            ->min('order_number');
    }

    private function checkPreviousQuizScore($chapterId)
    {
        $userId = Auth::id();
        // Temukan chapter pertama dalam course

        // Temukan chapter sebelumnya berdasarkan chapter_number
        $previousChapter = Chapter::where('chapter_number', '<', function ($query) use ($chapterId) {
            $query->select('chapter_number')
                ->from('chapters')
                ->where('id', $chapterId)
                ->limit(1);
        })
            ->orderBy('chapter_number', 'desc')
            ->first();
        if (!$previousChapter) {
            // Tidak ada chapter sebelumnya, jadi tidak perlu cek quiz
            return true;
        }

        // Temukan quiz untuk chapter sebelumnya
        $previousQuiz = Quiz::where('chapter_id', $previousChapter->id)->first();

        if (!$previousQuiz) {
            // Tidak ada quiz untuk chapter sebelumnya, tidak perlu cek quiz
            return true;
        }

        // Cek apakah user memiliki attempt dengan skor 100
        $quizAttempt = QuizAttempt::where('quiz_id', $previousQuiz->id)
            ->where('user_id', $userId)
            ->where('score', 100)
            ->exists();

        // Pastikan bahwa ada attempt dan skor adalah 100
        if (!$quizAttempt) {
            return false;
        }

        return true;
    }

    private function convertDurationToSeconds($duration)
    {
        list($hours, $minutes, $seconds) = explode(':', $duration);
        return ($hours * 3600) + ($minutes * 60) + $seconds;
    }

    // #[Layout('components.layouts.app')]
    public function render()
    {
        return view('livewire.courses.material-info', [
            'material' => $this->material,
            'quiz' => $this->quiz,
            'languages' => $this->languages,
            'quizAttempts' => $this->quizAttempts,
            'assignmentID' =>  $this->assignmentId,
            'assignment' =>  $this->assignment,
        ]);
    }
}

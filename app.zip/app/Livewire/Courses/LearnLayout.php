<?php

namespace App\Livewire\Courses;

use App\Models\Chapter;
use App\Models\Material;
use App\Models\UserMaterialStatus;
use Livewire\Component;
use Illuminate\Support\Facades\Auth;

class LearnLayout extends Component
{
  public $courseID;
  public $data;
  public $userId;

  public function mount($courseID)
  {
    $this->courseID = $courseID;
    $this->userId = Auth::id();
    $this->data = Chapter::where('course_id', $this->courseID)
      ->with(['materials' => function ($query) {
        $query->orderBy('order_number');
      }, 'materials.userMaterialStatus' => function ($query) {
        $query->where('user_id', $this->userId);
      }])
      ->orderBy('chapter_number')
      ->get();
  }

  public function placeholder()
  {
    return <<<'HTML'
        <div class="border border-blue-300 shadow rounded-md p-4 max-w-sm w-full mx-auto">
          <div class="animate-pulse flex space-x-4">
            <div class="rounded-full bg-slate-200 h-10 w-10"></div>
            <div class="flex-1 space-y-6 py-1">
              <div class="h-2 bg-slate-200 rounded"></div>
              <div class="space-y-3">
                <div class="grid grid-cols-3 gap-4">
                  <div class="h-2 bg-slate-200 rounded col-span-2"></div>
                  <div class="h-2 bg-slate-200 rounded col-span-1"></div>
                </div>
                <div class="h-2 bg-slate-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
        HTML;
  }

  public function render()
  {
    return view('livewire.courses.learn-layout');
  }
}

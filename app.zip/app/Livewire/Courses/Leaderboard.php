<?php

namespace App\Livewire\Courses;

use App\Models\Point;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Leaderboard extends Component
{
    public $courseID;
    public $topPoints;

    public function mount($courseID)
    {
        $this->courseID = $courseID;
        $this->topPoints = Point::where('course_id', $this->courseID)
        ->groupBy('user_id')
        ->selectRaw('user_id, SUM(points) as total_points')
        ->orderBy('total_points', 'desc')
        ->take(5)
        ->get();

        $this->topPoints = $this->topPoints->map(function ($point) {
            $user = User::find($point->user_id);
            $point->name = $user->name;
            $point->formatted_points = $this->formatPoints($point->total_points);
            return $point;
        });
    }

    private function formatPoints($points) {
        if ($points < 1000) {
            return $points;
        } elseif ($points < 1000000) {
            return number_format($points / 1000, 0) . 'K';
        } elseif ($points < 1000000000) {
            return number_format($points / 1000000, 0) . 'M';
        } else {
            return number_format($points / 1000000000, 0) . 'B';
        }
    }


    public function render()
    {
        return view('livewire.courses.leaderboard');
    }
}

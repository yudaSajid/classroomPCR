<?php

namespace App\Livewire;

use App\Models\Answer;
use App\Models\Point;
use App\Models\Question;
use App\Models\Quiz;
use App\Models\QuizAttempt;
use App\Models\User;
use Livewire\Component;

class TakeQuiz extends Component
{
    public $quiz;
    public $currentQuestion = 0;
    public $selectedAnswer = null;
    public $score = 0;
    public $questions;
    public $askedQuestions = [];
    public $completed = false;
    public $attempt;
    public $attemptCount = 0;
    public $userAttempts;
    public $messages;
    public $isPerfectScore;

    public function mount(Quiz $quiz)
    {
        $this->quiz = $quiz;
        $this->currentQuestion = 0;
        $this->selectedAnswer = null;
        $this->score = 0;
        $this->questions = $this->quiz->questions()->inRandomOrder()->limit(10)->get();
        $this->askedQuestions = [];
        $this->completed = false;
        $this->attemptCount = 0;
        $this->userAttempts = User::find(auth()->id())->quizAttempts()->where('quiz_id', $this->quiz->id)->count();

        // Tidak membuat QuizAttempt di sini, hanya mengecek jumlah attempt
        // if ($this->userAttempts >= 3) {
        //     // Handle max attempt reached scenario
        //     $this->messages = "Silahkan coba kembali ";
        // }
    }

    public function render()
    {
        if ($this->completed) {
            return view('livewire.take-quiz', [
                'quiz' => $this->quiz,
                'question' => null,
                'answers' => [],
                'score' => $this->score,
                'userAnswers' => $this->getUserAnswers(),
            ]);
        }

        if (empty($this->questions)) {
            return view('livewire.take-quiz', [
                'quiz' => $this->quiz,
                'question' => null,
                'answers' => [],
            ]);
        }

        if ($this->currentQuestion >= count($this->questions)) {
            $this->completed = true;
            $correctAnswers = $this->getUserAnswers()->where('is_correct', true)->count();
            $totalQuestions = count($this->questions);
            $this->score = ($correctAnswers / $totalQuestions) * 100;

            // Cek apakah skor sempurna
            $this->isPerfectScore = $this->score == 100;

            // Update the score in the QuizAttempt
            $this->attempt->update(['score' => $this->score, 'completed_at' => now()]);

            // Tambahkan logika untuk poin setelah quiz selesai
            $this->addPointsAfterQuiz();

            return view('livewire.take-quiz', [
                'quiz' => $this->quiz,
                'question' => null,
                'answers' => [],
                'score' => $this->score,
                'userAnswers' => $this->getUserAnswers(),
                'isPerfectScore' => $this->isPerfectScore,
            ]);
        }


        $question = $this->questions[$this->currentQuestion];
        if (in_array($question->id, $this->askedQuestions)) {
            // Skip this question, it's already been asked
            $this->currentQuestion++;
            return $this->render();
        }
        $this->askedQuestions[] = $question->id;

        return view('livewire.take-quiz', [
            'quiz' => $this->quiz,
            'question' => $question,
            'answers' => $question->answers,
        ]);
    }
    public function nextQuestion()
    {
        if ($this->selectedAnswer === null) {
            return;
        }

        $answer = Answer::find($this->selectedAnswer);

        $questions = $this->quiz->questions;
        $question = $questions[$this->currentQuestion];

        // Create a new QuizAttempt if not already created for this session
        if (!$this->attempt) {
            $this->attempt = User::find(auth()->id())->quizAttempts()->create([
                'quiz_id' => $this->quiz->id,
                'score' => 0,
            ]);
        }

        // Save the user's answer to the current attempt
        $this->attempt->userAnswers()->create([
            'question_id' => $question->id,
            'answer_id' => $this->selectedAnswer,
            'is_correct' => $answer->is_correct,
        ]);

        if ($answer->is_correct) {
            $this->score += 100 / count($this->questions);
        }

        $this->currentQuestion++;
        $this->selectedAnswer = null;
    }

    protected function addPointsAfterQuiz()
    {
        $userId = auth()->id();
        $quizId = $this->quiz->id;
        $courseId = $this->quiz->course_id; // Asumsikan ada relasi course di model Quiz

        // Cek apakah ini adalah quiz attempt pertama
        $isFirstAttempt = $this->userAttempts === 0;

        // Cek jika ini adalah attempt pertama dan skor 100
        if ($isFirstAttempt) {
            if ($this->score == 100) {
                // Tambah 20 poin untuk attempt pertama dengan skor 100
                Point::create([
                    'user_id' => $userId,
                    'points' => 20,
                    'quiz_id' => $quizId,
                    'course_id' => $courseId,
                    'reason' => 'First attempt with score 100',
                ]);
            } elseif ($this->score >= 80) {
                Point::create([
                    'user_id' => $userId,
                    'points' => 10,
                    'quiz_id' => $quizId,
                    'course_id' => $courseId,
                    'reason' => 'Score above 80 on quiz',
                ]);
            } elseif ($this->score < 80) {
                // Tambah 5 poin jika skor kurang dari atau sama dengan 80 dan bukan attempt pertama
                Point::create([
                    'user_id' => $userId,
                    'points' => 5,
                    'quiz_id' => $quizId,
                    'course_id' => $courseId,
                    'reason' => 'Score below or equal to 80 on quiz',
                ]);
            }
        }
    }



    public function selectAnswer($answerId)
    {
        $this->selectedAnswer = $answerId;
    }

    public function getUserAnswers()
    {
        return $this->attempt->userAnswers;
    }
}

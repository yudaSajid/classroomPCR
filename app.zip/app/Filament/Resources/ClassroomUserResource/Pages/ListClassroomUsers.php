<?php

namespace App\Filament\Resources\ClassroomUserResource\Pages;

use App\Filament\Resources\ClassroomUserResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListClassroomUsers extends ListRecords
{
    protected static string $resource = ClassroomUserResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}

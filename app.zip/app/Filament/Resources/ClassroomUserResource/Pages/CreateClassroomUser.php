<?php

namespace App\Filament\Resources\ClassroomUserResource\Pages;

use App\Filament\Resources\ClassroomUserResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateClassroomUser extends CreateRecord
{
    protected static string $resource = ClassroomUserResource::class;
}

<?php

namespace App\Filament\Resources\UserEducationResource\Pages;

use App\Filament\Resources\UserEducationResource;
use Filament\Resources\Pages\CreateRecord;

class CreateUserEducation extends CreateRecord
{
    protected static string $resource = UserEducationResource::class;
}

<?php

namespace App\Filament\Resources\ClassroomCourseResource\Pages;

use App\Filament\Resources\ClassroomCourseResource;
use Filament\Resources\Pages\CreateRecord;

class CreateClassroomCourse extends CreateRecord
{
    protected static string $resource = ClassroomCourseResource::class;
}

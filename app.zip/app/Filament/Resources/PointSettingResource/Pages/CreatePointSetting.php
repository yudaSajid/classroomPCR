<?php

namespace App\Filament\Resources\PointSettingResource\Pages;

use App\Filament\Resources\PointSettingResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePointSetting extends CreateRecord
{
    protected static string $resource = PointSettingResource::class;
}

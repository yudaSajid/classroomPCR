<?php

namespace App\Filament\Student\Resources\CourseDetailResource\Pages;

use App\Filament\Student\Resources\CourseDetailResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCourseDetail extends CreateRecord
{
    protected static string $resource = CourseDetailResource::class;
}

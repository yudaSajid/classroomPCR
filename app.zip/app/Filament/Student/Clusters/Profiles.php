<?php

namespace App\Filament\Clusters\Student;

use Filament\Clusters\Cluster;

class Profiles extends Cluster
{
    protected static ?string $navigationIcon = 'heroicon-o-squares-2x2';
}

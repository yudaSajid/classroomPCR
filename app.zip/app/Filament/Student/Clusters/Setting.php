<?php

namespace App\Filament\Clusters\Student;

use Filament\Clusters\Cluster;

class Setting extends Cluster
{
    protected static ?string $navigationIcon = 'heroicon-o-squares-2x2';
}

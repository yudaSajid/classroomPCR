<?php

namespace App\Filament\Teacher\Resources\ClassroomDetailResource\Pages;

use App\Filament\Teacher\Resources\ClassroomDetailResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateClassroomDetail extends CreateRecord
{
    protected static string $resource = ClassroomDetailResource::class;
}

<?php

namespace App\Filament\Clusters\Grades\Resources\ProjectSubmissionResource\Pages;

use App\Filament\Clusters\Grades\Resources\ProjectSubmissionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProjectSubmission extends CreateRecord
{
    protected static string $resource = ProjectSubmissionResource::class;
}

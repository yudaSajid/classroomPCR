<?php

namespace App\Filament\Clusters\Grades\Resources\ClassroomResource\Pages;

use App\Filament\Clusters\Grades\Resources\ClassroomResource;
use Filament\Resources\Pages\CreateRecord;

class CreateClassroom extends CreateRecord
{
    protected static string $resource = ClassroomResource::class;
}

<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-4">
        
        <div class="flex items-center justify-between mb-8">
            <div>
                
                <h2 class="text-2xl font-semibold text-gray-900 dark:text-gray-100">Your Achievement Badges</h2>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Track your progress and earn rewards</p>
            </div>
            
            <div class="flex items-center gap-2 px-6 py-3 bg-white border border-gray-100 rounded-lg shadow-sm
                        dark:bg-gray-800 dark:border-gray-700 dark:shadow-lg"> 
                <svg class="w-5 h-5 text-indigo-500 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"> 
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span class="font-medium text-gray-900 dark:text-gray-100"><?php echo e(number_format($this->getUserPoints())); ?></span> 
                <span class="text-sm text-gray-500 dark:text-gray-400">points</span> 
            </div>
        </div>

        
        <div class="grid grid-cols-4 gap-6 sm:grid-cols-1 lg:grid-cols-4 xl:grid-cols-4">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->getBadges(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="relative overflow-hidden transition-all duration-300 rounded-xl hover:shadow-xl
                           bg-white dark:bg-gray-800 shadow-md dark:shadow-lg group"> 
                    <div class="relative p-6 <?php echo e(!$badge['is_claimable'] ? 'grayscale' : ''); ?>">
                        <div class="flex justify-center mb-4">
                            <div
                                class="relative w-24 h-24 transition-transform duration-300 transform group-hover:scale-110">
                                <!--[if BLOCK]><![endif]--><?php if($badge['image']): ?>
                                    <img src="<?php echo e(Storage::url($badge['image'])); ?>" alt="<?php echo e($badge['name']); ?>"
                                        class="object-cover w-full h-full rounded-full ring-4 ring-offset-2
                                               <?php echo e($badge['is_claimed'] ? 'ring-green-500 dark:ring-green-400' : ($badge['is_claimable'] ? 'ring-indigo-500 dark:ring-indigo-400' : 'ring-gray-200 dark:ring-gray-700')); ?>

                                               dark:ring-offset-gray-800"> 
                                <?php else: ?>
                                    <div class="flex items-center justify-center w-full h-full text-3xl font-bold text-white rounded-full ring-4 ring-offset-2
                                                <?php echo e($badge['is_claimed'] ? 'ring-green-500 dark:ring-green-400' : ($badge['is_claimable'] ? 'ring-indigo-500 dark:ring-indigo-400' : 'ring-gray-200 dark:ring-gray-700')); ?>

                                                dark:ring-offset-gray-800" 
                                        style="background-color: <?php echo e($badge['color']); ?>">
                                        <?php echo e(substr($badge['name'], 0, 2)); ?>

                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                <!--[if BLOCK]><![endif]--><?php if($badge['is_claimed']): ?>
                                    <div
                                        class="absolute -top-1 -right-1 p-1.5 text-white bg-green-500 rounded-full shadow-lg dark:bg-green-700 dark:text-green-100"> 
                                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd"
                                                d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                                clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>

                        <div class="text-center">
                            <h3 class="mb-2 text-lg font-semibold text-gray-800 dark:text-gray-100"><?php echo e($badge['name']); ?></h3> 
                            <p class="mb-4 text-sm text-gray-600 dark:text-gray-300"><?php echo $badge['description']; ?></p> 
                            <div class="mb-4">
                                <!--[if BLOCK]><![endif]--><?php if($badge['type']->value === \App\Enums\BadgeType::Custom->value): ?>
                                    <span
                                        class="px-3 py-1 text-sm border rounded-full shadow-sm
                                        bg-amber-50 text-amber-600 border-amber-200
                                        dark:bg-amber-900 dark:text-amber-200 dark:border-amber-700">Gifted</span> 
                                <?php else: ?>
                                    <span
                                        class="px-3 py-1 text-sm rounded-full
                                        <?php echo e($badge['is_claimable'] ? 'text-indigo-600 bg-indigo-50 dark:text-indigo-200 dark:bg-indigo-900' : 'text-gray-600 bg-gray-100 dark:text-gray-300 dark:bg-gray-700'); ?>"> 
                                        <?php echo e(number_format($badge['point_require'])); ?> points required
                                    </span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <!--[if BLOCK]><![endif]--><?php if($badge['is_claimable'] && !$badge['is_claimed']): ?>
                                <button wire:click="claimBadge(<?php echo e($badge['id']); ?>)" wire:loading.attr="disabled"
                                    class="w-full px-4 py-2 text-sm font-medium text-white transition-all duration-300 bg-indigo-600 rounded-lg shadow-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50
                                           dark:bg-indigo-700 dark:hover:bg-indigo-600 dark:focus:ring-offset-gray-800"> 
                                    <span class="flex items-center justify-center">
                                        <svg wire:loading.remove class="w-5 h-5 mr-2" fill="none"
                                            stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                        <svg wire:loading class="w-5 h-5 mr-2 animate-spin" fill="none"
                                            stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                        </svg>
                                        <span wire:loading.remove>Claim Badge</span>
                                        <span wire:loading>Claiming...</span>
                                    </span>
                                </button>
                            <?php elseif($badge['is_claimed']): ?>
                                <span
                                    class="inline-block w-full px-4 py-2 text-sm font-medium rounded-lg
                                           text-green-700 bg-green-100 dark:bg-green-800 dark:text-green-200"> 
                                    <span class="flex items-center justify-center">
                                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd"
                                                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                                clip-rule="evenodd" />
                                        </svg>
                                        Claimed
                                    </span>
                                </span>
                            <?php else: ?>
                                <span
                                    class="inline-block w-full px-4 py-2 text-sm font-medium rounded-lg
                                           text-gray-500 bg-gray-100 dark:bg-gray-700 dark:text-gray-200"> 
                                    <span class="flex items-center justify-center">
                                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor"
                                            viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                        </svg>
                                        Not Yet Available
                                    </span>
                                </span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if(!$badge['is_claimed'] && !$badge['is_claimable']): ?>
                        <div class="h-2 bg-gray-200 dark:bg-gray-700"> 
                            <div class="h-full transition-all duration-300 bg-gradient-to-r
                                        from-indigo-600 to-purple-600
                                        dark:from-indigo-500 dark:to-purple-500" 
                                style="width: <?php echo e(min(100, ($this->getUserPoints() / $badge['point_require']) * 100)); ?>%">
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <div class="p-4 mt-8">
        <h3 class="text-xl font-semibold text-gray-900 dark:text-gray-100">Point History</h3> 
        <div class="mt-4 bg-white shadow-sm rounded-xl dark:bg-gray-800 dark:shadow-lg dark:border dark:border-gray-700"> 
            <div class="overflow-hidden">
                <ul class="divide-y divide-gray-100 dark:divide-gray-700"> 
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $this->getPointHistory(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li
                            class="relative flex items-center justify-between p-4 transition-all duration-200 group
                                   hover:bg-gray-50 dark:hover:bg-gray-700"> 
                            <div class="flex items-center space-x-4">
                                <div class="flex-shrink-0">
                                    <!--[if BLOCK]><![endif]--><?php if(str_contains(strtolower($point->reason), 'quiz')): ?>
                                        <div class="p-2 rounded-lg
                                                    text-purple-600 bg-purple-100 dark:text-purple-300 dark:bg-purple-900/50"> 
                                            <svg class="w-6 h-6" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                        </div>
                                    <?php elseif(str_contains(strtolower($point->reason), 'course')): ?>
                                        <div class="p-2 rounded-lg
                                                    text-blue-600 bg-blue-100 dark:text-blue-300 dark:bg-blue-900/50"> 
                                            <svg class="w-6 h-6" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                                            </svg>
                                        </div>
                                    <?php else: ?>
                                        <div class="p-2 rounded-lg
                                                    text-emerald-600 bg-emerald-100 dark:text-emerald-300 dark:bg-emerald-900/50"> 
                                            <svg class="w-6 h-6" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
                                            </svg>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900 dark:text-gray-100"><?php echo e($point->reason); ?></p> 
                                    <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($point->created_at->diffForHumans()); ?></p> 
                                </div>
                            </div>

                            <div class="flex items-center space-x-2">
                                <span
                                    class="inline-flex items-center px-3 py-1 text-sm font-medium rounded-full
                                           <?php echo e($point->points >= 0 ? 'text-green-700 bg-green-100 dark:text-green-200 dark:bg-green-800' : 'text-red-700 bg-red-100 dark:text-red-200 dark:bg-red-800'); ?>"> 
                                    <?php echo e($point->points >= 0 ? '+' : ''); ?><?php echo e($point->points); ?>

                                </span>
                                <div class="transition-opacity opacity-0 group-hover:opacity-100">
                                    <!--[if BLOCK]><![endif]--><?php if($point->course): ?>
                                        <span
                                            class="inline-flex items-center px-2 py-1 text-xs rounded
                                                   text-gray-600 bg-gray-100 dark:text-gray-300 dark:bg-gray-700"> 
                                            <?php echo e(Str::limit($point->course->title, 20)); ?>

                                        </span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="p-8 text-center">
                            <div
                                class="inline-flex items-center justify-center w-16 h-16 mx-auto mb-4 rounded-full bg-gray-50 dark:bg-gray-700"> 
                                <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                </svg>
                            </div>
                            <p class="text-gray-500 dark:text-gray-400">No point history available yet</p> 
                        </li>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?><?php /**PATH D:\SAJID\PA\newest\e-learning-app-multi\resources\views/filament/student/pages/skill-badge-page.blade.php ENDPATH**/ ?>
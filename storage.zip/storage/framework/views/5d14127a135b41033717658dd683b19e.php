<div class="w-full max-w-sm p-4 mx-auto border border-blue-300 rounded-md shadow">
  <div class="flex space-x-4 animate-pulse">
    <div class="w-10 h-10 rounded-full bg-slate-200"></div>
    <div class="flex-1 py-1 space-y-6">
      <div class="h-2 rounded bg-slate-200"></div>
      <div class="space-y-3">
        <div class="grid grid-cols-3 gap-4">
          <div class="h-2 col-span-2 rounded bg-slate-200"></div>
          <div class="h-2 col-span-1 rounded bg-slate-200"></div>
        </div>
        <div class="h-2 rounded bg-slate-200"></div>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\SAJID\PA\newest\e-learning-app-multi\storage\framework\views/bddfc6ef415dcf81454aa88bd9e173c7.blade.php ENDPATH**/ ?>
<div
    class="relative flex flex-col h-full max-w-xs overflow-hidden transition-all duration-300 ease-out transform bg-white shadow-xl group rounded-xl dark:bg-gray-800/95 hover:shadow-2xl hover:-translate-y-2">
    <a href="<?php echo e(route('filament.student.resources.course-details.view', ['record' => $route])); ?>"
        class="absolute inset-0 z-10" wire:navigate aria-label="<?php echo e($title); ?>"></a>
    <div class="relative flex-grow p-5 pointer-events-none">
        
        <span
            class="absolute top-3 left-3 z-20 bg-fuchsia-600/90 backdrop-blur-sm text-white text-xs font-medium px-3 py-1.5 rounded-full shadow-lg">
            <?php echo e($status); ?>

        </span>

        
        <div class="relative w-full h-40 mb-4 overflow-hidden rounded-lg">
            <img class="object-cover w-full h-full transition-transform duration-500 transform group-hover:scale-110"
                src="<?php echo e(asset('storage/' . $image)); ?>" alt="<?php echo e($title); ?>">
            <div
                class="absolute inset-0 transition-opacity duration-300 opacity-0 bg-gradient-to-t from-black/30 to-transparent group-hover:opacity-100">
            </div>
        </div>

        
        <div class="space-y-4">
            <h2 class="text-xl font-bold text-gray-800 dark:text-white min-h-[55px] leading-tight">
                <?php echo e($title); ?>

            </h2>

            
            <div class="flex items-center justify-between text-sm text-gray-600 dark:text-gray-300">
                <div class="flex items-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-fuchsia-500" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                            d="M3 5h18M9 3v2m6-2v2m-6 16v-6h6v6m-2-8h4m-10 0H5" />
                    </svg>
                    <span><?php echo e($completedMaterials); ?>/<?php echo e($totalMaterials); ?> Materi</span>
                </div>
            </div>

            
            <div class="relative w-full h-3 overflow-hidden bg-gray-200 rounded-full dark:bg-gray-700">
                <div class="absolute h-full transition-all duration-500 ease-out bg-gradient-to-r from-fuchsia-500 to-fuchsia-600"
                    style="width: <?php echo e($progress); ?>%">
                </div>
                <div
                    class="absolute inset-0 flex items-center justify-center text-xs font-medium text-white mix-blend-difference">
                    <?php echo e(round($progress, 1)); ?>%
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\SAJID\PA\newest\e-learning-app-multi\resources\views/livewire/class-card.blade.php ENDPATH**/ ?>
<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH D:\SAJID\PA\newest\e-learning-app-multi\resources\views/livewire/projects/list-project.blade.php ENDPATH**/ ?>